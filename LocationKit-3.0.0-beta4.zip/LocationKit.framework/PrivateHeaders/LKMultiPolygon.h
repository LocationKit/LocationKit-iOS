//
// Created by John Fontaine on 6/22/15.
// Copyright (c) 2015 SocialRadar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LKGeometryShape.h"


@interface LKMultiPolygon : LKGeometryShape

@end