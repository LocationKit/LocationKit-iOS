//
// Created by an on 10/22/15.
// Copyright (c) 2015 SocialRadar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>
#import "LKVisit.h"
#import "LKSearchRequest.h"
#import "LKSetting.h"
#import "LKVisitCriteria.h"
#import "LKPerson.h"


typedef NS_OPTIONS(NSUInteger, LKActivityMode) {
    LKActivityModeUnknown,
    LKActivityModeStationary,
    LKActivityModeWalking,
    LKActivityModeRunning,
    LKActivityModeCycling,
    LKActivityModeAutomotive
};


@class LKKeepAliveLoop;
@protocol LKLocationManagerDelegate;


@interface LKLocationManager : CLLocationManager

@property(nonatomic) BOOL isRunning;
@property(nonatomic) BOOL debug;
@property(nonatomic, readonly)  NSString* _Nullable deviceId;
@property(nonatomic, readonly) NSString* _Nullable version;
@property(nonatomic, strong) NSString* _Nullable apiToken;

@property(nonatomic) NSTimeInterval locationUpdateInterval;
@property(nonatomic) BOOL detectVenues;


- (void)requestPlace:(void (^ _Nonnull)(LKPlace* _Nullable place, NSError* _Nullable error))handler;
- (void)requestLocation:(void (^ _Nonnull)(CLLocation* _Nullable location, NSError* _Nullable error))handler;


- (void)startMonitoringForRegionWithCriteria:(LKVisitCriteria* _Nonnull)criteria;
- (void)stopMonitoringForRegionWithCriteria:(LKVisitCriteria* _Nonnull)criteria;
@property(nonatomic, readonly) NSArray* _Nonnull monitoredCriteria;

- (void)requestPeopleAtCurrentPlace:(void (^ _Nonnull)(NSArray* _Nullable people, LKVenue* _Nullable venue, NSError* _Nullable error))handler;
- (void)requestPeopleNearby:(void (^ _Nonnull)(NSArray* _Nullable people, NSError* _Nullable error))handler;


- (void)searchForPlacesWithRequest:(LKSearchRequest* _Nonnull)request completionHandler:(void (^ _Nonnull)(NSArray* _Nullable places, NSError* _Nullable error))handler;
- (void)requestPlaceForLocation:(CLLocation* _Nonnull)location completionHandler:(void (^ _Nonnull)(LKPlace* _Nullable place, NSError* _Nullable error))handler;


- (void)requestPriorVisits:(void (^ _Nonnull)(NSArray* _Nullable visits, NSError* _Nullable error))handler;
- (void)requestHomeAddress:(void (^ _Nonnull)(LKPlacemark* _Nullable, NSError* _Nullable))handler;
- (void)requestWorkAddress:(void (^ _Nonnull)(LKPlacemark* _Nullable, NSError* _Nullable))handler;

/*
 *  updateUserValues:
 *
 *  Discussion:
 *      Update user values. Use LKUserValue constants as dictionary keys.
 *
 */
- (void)setUserValues:(NSDictionary* _Nonnull)userValues;

- (void)optOut:(void (^ _Nonnull)(NSError* _Nullable))handler;

- (void)setOperationMode:(LKSetting* _Nonnull)setting;

- (void)pause;

- (NSError* _Nullable)resume;


@end

NS_ASSUME_NONNULL_BEGIN

@protocol LKLocationManagerDelegate <NSObject>

@optional

// Methods for parity with CLLocationManagerDelegate
- (void)locationManager:(LKLocationManager *)manager didUpdateLocations:(NSArray *)locations;
- (void)locationManager:(LKLocationManager *)manager didFailWithError:(NSError *)error;
- (void)locationManager:(LKLocationManager *)manager didFinishDeferredUpdatesWithError:(NSError *)error;

- (void)locationManagerDidPauseLocationUpdates:(LKLocationManager *)manager;
- (void)locationManagerDidResumeLocationUpdates:(LKLocationManager *)manager;

- (void)locationManager:(LKLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading;
- (BOOL)locationManagerShouldDisplayHeadingCalibration:(LKLocationManager *)manager;

- (void)locationManager:(LKLocationManager *)manager didEnterRegion:(CLRegion *)region;
- (void)locationManager:(LKLocationManager *)manager didExitRegion:(CLRegion *)region;
- (void)locationManager:(LKLocationManager *)manager didDetermineState:(CLRegionState)state forRegion:(CLRegion *)region;
- (void)locationManager:(LKLocationManager *)manager monitoringDidFailForRegion:(nullable CLRegion *)region withError:(NSError *)error;
- (void)locationManager:(LKLocationManager *)manager didStartMonitoringForRegion:(CLRegion *)region;

- (void)locationManager:(LKLocationManager *)manager didRangeBeacons:(NSArray<CLBeacon *> *)beacons inRegion:(CLBeaconRegion *)region;
- (void)locationManager:(LKLocationManager *)manager rangingBeaconsDidFailForRegion:(CLBeaconRegion *)region withError:(NSError *)error;

- (void)locationManager:(LKLocationManager *)manager didVisit:(CLVisit *)visit;

- (void)locationManager:(LKLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status;

// LocationKit additions
- (void)locationManager:(LKLocationManager *)manager didStartVisit:(LKVisit *)visit;
- (void)locationManager:(LKLocationManager *)manager didEndVisit:(LKVisit *)visit;
- (void)locationManager:(LKLocationManager *)manager willChangeActivityMode:(LKActivityMode)mode;
- (void)locationManager:(LKLocationManager *)manager changeRegion:(NSString *)obj;

@end

NS_ASSUME_NONNULL_END
