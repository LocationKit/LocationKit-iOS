//
// Created by SocialRadar on 6/3/15.
// Copyright (c) 2015 SocialRadar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@interface LKPlacemark : NSObject <NSCoding>

@property(nonatomic, strong) NSString *addressId;
@property(nonatomic, strong) NSString *geometryId;
@property(nonatomic, strong) NSString *coordinatesType;
@property(nonatomic, strong) NSString *countryCode;
@property(nonatomic, strong) NSString *streetName;
@property(nonatomic, strong) NSString *streetNumber;
@property(nonatomic, strong) NSString *state;
@property(nonatomic) double latitude;
@property(nonatomic) double longitude;
@property(nonatomic, readonly) NSString *country;
@property(nonatomic, readonly) NSString *locality;
@property(nonatomic, readonly) NSString *postalCode;
@property(nonatomic, readonly) NSString *location;

@property NSUInteger venueCount;


- (id)initWithPlacemark:(CLPlacemark *)placemark;


@end